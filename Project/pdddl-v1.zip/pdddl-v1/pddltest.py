import pddlpy

domprob = pddlpy.DomainProblem('domain-03.pddl', 'problem-03.pddl')

print("Stationary init:", domprob.initialstate(), '\n')

print("Actions we can take:", list(domprob.operators()),'\n')

print("What is this???", len(list(domprob.ground_operator('op1'))), '\n')

print("Preconditions:", len(list(domprob.ground_operator('op1'))[2].precondition_pos), '\n')